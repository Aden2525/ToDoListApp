package com.plcoding.mvvmtodoapp.util

object Routes {
    const val TODO_LIST = "todo_list"
    const val ADD_EDIT_TODO = "add_edit_todo"
}